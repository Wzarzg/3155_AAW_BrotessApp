package pe.edu.upc.brotessapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrotessAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(BrotessAppApplication.class, args);
    }

}
