package pe.edu.upc.brotessapp.dtos;


public class SintomasEnfermedadDTO {

    private int idSintomasE;
    private String nombreSintoma;

    public int getIdSintomasE() {
        return idSintomasE;
    }

    public void setIdSintomasE(int idSintomasE) {
        this.idSintomasE = idSintomasE;
    }

    public String getNombreSintoma() {
        return nombreSintoma;
    }

    public void setNombreSintoma(String nombreSintoma) {
        this.nombreSintoma = nombreSintoma;
    }
}
