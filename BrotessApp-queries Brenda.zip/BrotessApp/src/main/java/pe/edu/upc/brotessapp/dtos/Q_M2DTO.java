package pe.edu.upc.brotessapp.dtos;

public class Q_M2DTO {
    private String nombreEnfermedad;
    private String descripcionPrevencion;

    public String getNombreEnfermedad() {
        return nombreEnfermedad;
    }

    public void setNombreEnfermedad(String nombreEnfermedad) {
        this.nombreEnfermedad = nombreEnfermedad;
    }

    public String getDescripcionPrevencion() {
        return descripcionPrevencion;
    }

    public void setDescripcionPrevencion(String descripcionPrevencion) {
        this.descripcionPrevencion = descripcionPrevencion;
    }
}
