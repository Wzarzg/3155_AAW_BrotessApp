package pe.edu.upc.brotessapp.dtos;

public class Q_T2DTO {

    private String distrito;
    private int cantidadContagios;

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public int getCantidadContagios() {
        return cantidadContagios;
    }

    public void setCantidadContagios(int cantidadContagios) {
        this.cantidadContagios = cantidadContagios;
    }
}
