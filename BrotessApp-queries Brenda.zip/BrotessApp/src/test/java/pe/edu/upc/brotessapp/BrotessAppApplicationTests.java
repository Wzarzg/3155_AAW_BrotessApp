package pe.edu.upc.brotessapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrotessAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
