package pe.edu.upc.brotessapp.dtos;

public class TipoEnfermedadDTO {

    private int idTipoE;

    private String nombreTipoE;


    public int getIdTipoE() {
        return idTipoE;
    }

    public void setIdTipoE(int idTipoE) {
        this.idTipoE = idTipoE;
    }

    public String getNombreTipoE() {
        return nombreTipoE;
    }

    public void setNombreTipoE(String nombreTipoE) {
        this.nombreTipoE = nombreTipoE;
    }

}
